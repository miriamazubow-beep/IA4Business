# Pendências

Substitui a página "Pendências" do Notion enquanto o conector não está ligado (ver `automacoes.md`). A rotina diária lê este arquivo.

## Resumo da última execução (01/10/2026, 09:42)
- **Vence hoje:** nada.
- **Atrasou:** entrega da NP2 (prazo 21/09, 10 dias de atraso).
- **Anda bem:** NP3 (prazo 08/10, faltam 7 dias); 4 itens sem prazo definido.

## A fazer
- [ATRASADO] Entregar a NP2: push no GitHub e link do repositório na tarefa do Canvas — prazo 21/09
- NP3: agente rodando com evidência — prazo 08/10
- Preencher o `diario.md` com usos reais — sem prazo
- Colar uma mensagem real minha como amostra no `prompts.md` (hoje é um placeholder) — sem prazo
- Conectar o Notion e montar o board de parcerias — sem prazo
- Primeiro experimento: registrar as 5 próximas propostas da Camila (ver `problema.md`) — sem prazo

## Feito
(vazio)
