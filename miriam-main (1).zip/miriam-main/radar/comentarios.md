# Comentários coletados

## Alvo
- Perfil: Sallve (marca de skincare, 1,6 milhão de seguidores), `instagram.com/sallve` — é o tipo de marca que me procura (ver `contexto/cliente.md`).
- Post: `https://www.instagram.com/p/Dd2NWZOiRvk/`, vídeo de 28/09/2026, publi feita por uma criadora parceira e publicada em conjunto com a marca.
- Legenda: "#publi | O Protetor Solar Antimanchas com Cor da [marca] tem FPS 90, cobertura média e construível e acabamento sequinho, sem esbranquiçar ou acinzentar na pele negra. Conheça no site da Sallve e use meu cupom [cupom] para ter 10% de desconto em compras acima de R$149, por tempo limitado."
- O post anuncia 95 comentários (o número inclui as respostas).

## Registro da coleta
| Data | Hora | O que foi feito | Resultado |
|---|---|---|---|
| 01/10/2026 | 09:44 | Abri o post `instagram.com/p/DdkE5ktDULH/` sem estar logada | 0 comentários. A página só mostra o botão de entrar. Sem login não existe coleta. |
| 01/10/2026 | 10:31 | Logada, abri o post `Dd2NWZOiRvk` e li a primeira tela | 15 comentários |
| 01/10/2026 | 10:31 | Rolei a lista em passos, guardando a cada passo | 29, depois 42. A partir daí não carregou mais nada em 12 passos seguidos |

Total: **42 comentários** de primeiro nível, dos 95 anunciados (44%). Não abri as respostas de cada comentário. É uma amostra, não o retrato completo.

## Comentários
Sem o @ de quem escreveu, na ordem em que apareceram.

1. 😍😍😍😍
2. 😍😍😍😍😍😍
3. 😍
4. 🧡🧡
5. Uso e amo demais 😍
6. Muito bom amiga!
7. 😍😍😍
8. ameii😍
9. Parece perfeito mesmo ✨
10. Amei ❤️
11. ❤️
12. Amei ,prático e rápido de passar, ,gosto de coisas assim 😅 👏🏼👏🏼😍
13. Perfeito 🔥🔥🔥
14. Sempre boas dicas!! Já quero testar 😍
15. amei 🤌🏼
16. Nossa, comprei um kit deles! Amei
17. Quero testar super!!!❤️
18. Amei
19. Proteção e maquiagem juntos !! Perfeito 😍 Já quero!
20. 😍😍😍😍😍Tudooo
21. Acho que esse é o meu tom, ameiiii
22. 😍
23. Gostei hein!!!, bem prático 👏
24. tudoooo❤️❤️❤️ to louca pata testar
25. Top 😍
26. É muito prático! Eu amo
27. Esse protetor é perfeito!!
28. Já quero !
29. o tanto que minha pele fica linda e sequinha com os protetores com cor da sallve 😍
30. que cobertura impecável 😍
31. 🔥🔥🙌
32. Transfere muito ?!
33. Uauuu! Me passa o nomeeee
34. Ele é surreal. Eu, preta, me senti representada. Perfeitooooo. Após, cela com um pó solto translúcido. Pronto.
35. Gente, transfere ?
36. chocunt
37. Tão prático né, amei! Tua pele ficou mais linda ainda com ele 😍
38. Proteção para a Blz rara né [nome]😎🫰🏽✨
39. Adorei o resultado,super dica 👏🏾😍
40. Lindíssima. 😍
41. Sempre tem as melhores indicações, arrasa demais 😍🤎
42. As melhores dicas vem dela!
