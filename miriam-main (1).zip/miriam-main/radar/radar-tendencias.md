# Radar de tendências

## Origem
- Perfil: Sallve (skincare, 1,6 milhão de seguidores).
- Post: 1 post, `https://www.instagram.com/p/Dd2NWZOiRvk/`, publi de protetor solar com cor feita por uma criadora parceira, de 28/09/2026.
- Comentários: **42 coletados** em 01/10/2026, dos 95 que o post anuncia (44%). Só comentários de primeiro nível. É amostra de um post só.
- Os comentários estão em `radar/comentarios.md`.

## Tabela de relevância
| Categoria | Quantos | % | Exemplos |
|---|---|---|---|
| ELOGIO | 20 | 48% | "Esse protetor é perfeito!!" · "que cobertura impecável 😍" |
| RUÍDO | 9 | 21% | "😍😍😍😍" · "chocunt" |
| QUERO | 5 | 12% | "Já quero !" · "Quero testar super!!!❤️" |
| NÃO CLASSIFICADO | 5 | 12% | "As melhores dicas vem dela!" · "Lindíssima. 😍" |
| DÚVIDA | 3 | 7% | "Transfere muito ?!" · "Uauuu! Me passa o nomeeee" |
| PREÇO | 0 | 0% | — |
| CRÍTICA | 0 | 0% | — |
| **Total** | **42** | **100%** | |

Comentário só de emoji entrou em RUÍDO: não diz nada sobre o produto.

## O que caiu em NÃO CLASSIFICADO
Ficou em 12%, abaixo dos 20% que pedem categoria nova. Mas os 5 dizem a mesma coisa: são elogio à criadora, não ao produto ("Sempre tem as melhores indicações, arrasa demais", "Muito bom amiga!"). Se isso se repetir em outro post, a categoria que falta é **CONFIANÇA NA CRIADORA**. Outros 2 comentários já classificados também citam as "dicas" dela (14 e 39).

## Passo a passo
1. Escolhi um perfil de marca do tipo que me procura, com um post de mais de 30 comentários.
2. Sem login, o Instagram mostrou zero comentários. Com login, a primeira tela trouxe 15.
3. Rolei a lista em passos, guardando o que aparecia a cada passo: 29, depois 42. Não carregou mais que isso.
4. Tirei o @ de quem escreveu e classifiquei cada comentário em exatamente uma das seis categorias fechadas (QUERO, PREÇO, DÚVIDA, ELOGIO, CRÍTICA, RUÍDO), com NÃO CLASSIFICADO para o que ficou ambíguo.
5. Li o que caiu em NÃO CLASSIFICADO para ver se pedia categoria nova.

## Leitura de negócio
- A única dúvida de produto que se repete é se o protetor transfere (2 de 42), e o vídeo não responde: é o que eu mostraria em uma publi minha desse tipo de produto.
- O cupom de 10% está na legenda e nenhum comentário fala de preço ou de cupom; a intenção de compra (12%) aparece como "quero testar", não como reação ao desconto.
- 5 comentários elogiam a criadora e não o produto: parte do que a marca compra numa publi é a confiança na indicação, e isso é argumento para eu levar a uma negociação de valor.
